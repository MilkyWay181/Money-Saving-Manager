package com.example.moneysavingmanager;

import android.app.Activity;

public class LogInActivity extends Activity {
}
