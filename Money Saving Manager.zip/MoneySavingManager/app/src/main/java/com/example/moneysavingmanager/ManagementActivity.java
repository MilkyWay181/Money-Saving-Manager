package com.example.moneysavingmanager;

import android.app.Activity;

public class ManagementActivity extends Activity {
}

